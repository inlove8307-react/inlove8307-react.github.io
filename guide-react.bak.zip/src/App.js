import React from "react";
import Sample from "./pages/Sample";

function App() {
	return (
		<Sample />
	);
}

export default App;
